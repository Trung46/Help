const vueinst = new Vue({
    el: '#app',
    data: {
        showPeopleSection: false,
        showManagersSection: true,
        showBranchesSection: false,
        showProfileSection: false,
        users: [],
        branches: [],
        editingBranchId: null,
        showEditForm: false, // Track visibility of the edit form
        editingUserId: null, // Use user_id as the primary key
        showEditUserForm: false // Track visibility of the edit user form
    },
    methods: {
        toggleSection(section) {
            this.showPeopleSection = false;
            this.showManagersSection = false;
            this.showBranchesSection = false;
            this.showProfileSection = false;
            if (section === 'profile') {
                this.showProfileSection = true;
            }
            if (section === 'managers') {
                this.showManagersSection = true;
                this.fetchUsers();
            }
            if (section === 'branches') {
                this.showBranchesSection = true;
                this.fetchBranches();
            }
        },
        fetchUsers() {
            fetch('/users')
                .then(response => response.json())
                .then(data => {
                    this.users = data;
                })
                .catch(error => console.error('Error fetching users:', error));
        },
        fetchBranches() {
            fetch('/branches')
                .then(response => response.json())
                .then(data => {
                    this.branches = data;
                    console.log('Branches fetched:', this.branches); // Add log to check the fetched branches
                })
                .catch(error => console.error('Error fetching branches:', error));
        },
        editTable(type, id) {
            console.log('Editing', type, 'with ID:', id); // Log the type and ID to verify it is correct
            if (type === 'branches') {
                const branch = this.branches.find(b => b.branch_id === id); // Use branch_id as the key
                if (branch) {
                    this.editingBranchId = branch.branch_id; // Store the branch ID
                    this.showEditForm = true; // Show the edit form
                    this.$nextTick(() => { // Ensure the form is rendered before accessing elements
                        // Pre-fill the form with existing branch details
                        document.getElementById('edit-branch-name').value = branch.name;
                        document.getElementById('edit-branch-location').value = branch.location;
                        document.getElementById('edit-branch-phone-number').value = branch.phone_number;
                        document.getElementById('edit-branch-email').value = branch.email;
                    });
                }
            } else if (type === 'users') {
                const user = this.users.find(u => u.user_id === id); // Use user_id as the key
                if (user) {
                    this.editingUserId = user.user_id; // Store the user ID
                    this.showEditUserForm = true; // Show the edit user form
                    this.$nextTick(() => { // Ensure the form is rendered before accessing elements
                        // Pre-fill the form with existing user details
                        document.getElementById('edit-user-full-name').value = user.full_name;
                        document.getElementById('edit-user-email').value = user.email;
                        document.getElementById('edit-user-phone-number').value = user.phone_number;
                        document.getElementById('edit-user-username').value = user.user_name;
                        document.getElementById('edit-user-password').value = user.password;
                        document.getElementById('edit-user-associated-branch').value = user.associated_branch;
                        document.getElementById('edit-user-manager').checked = user.bool_manager;
                        document.getElementById('edit-user-admin').checked = user.bool_admin;
                    });
                }
            }
        },
        updateBranch() {
            if (this.editingBranchId) {
                this.editBranch(this.editingBranchId); // Use the stored branch ID for the update
            }
        },
        editBranch(branchId) {
            const name = document.getElementById('edit-branch-name').value;
            const location = document.getElementById('edit-branch-location').value;
            const phoneNumber = document.getElementById('edit-branch-phone-number').value;
            const email = document.getElementById('edit-branch-email').value;

            fetch(`/branches/edit/${branchId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ name: name, location: location, phone_number: phoneNumber, email: email })
            })
            .then(response => response.json())
            .then(data => {
                console.log('Branch updated:', data); // Log the updated branch data
                this.fetchBranches(); // Refresh the branches list
                this.showEditForm = false; // Hide the edit form
            })
            .catch(error => console.error('Error updating branch:', error));
        },
        updateUser() {
            if (this.editingUserId) {
                this.editUser(this.editingUserId); // Use the stored user ID for the update
            }
        },
        editUser(userId) {
            const fullName = document.getElementById('edit-user-full-name').value;
            const email = document.getElementById('edit-user-email').value;
            const phoneNumber = document.getElementById('edit-user-phone-number').value;
            const username = document.getElementById('edit-user-username').value;
            const password = document.getElementById('edit-user-password').value;
            const associatedBranch = document.getElementById('edit-user-associated-branch').value;
            const manager = document.getElementById('edit-user-manager').checked;
            const admin = document.getElementById('edit-user-admin').checked;

            fetch(`/users/${userId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ full_name: fullName, email: email, phone_number: phoneNumber, user_name: username, password: password, associated_branch: associatedBranch, bool_manager: manager, bool_admin: admin })
            })
            .then(response => response.json())
            .then(data => {
                console.log('User updated:', data); // Log the updated user data
                this.fetchUsers(); // Refresh the users list
                this.showEditUserForm = false; // Hide the edit user form
            })
            .catch(error => console.error('Error updating user:', error));
        },
        deleteBranch(branchId) {
            fetch(`/branches/delete/${branchId}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                console.log('Branch deleted:', data); // Log the deleted branch data
                this.fetchBranches(); // Refresh the branches list
                this.showEditForm = false; // Hide the edit form
            })
            .catch(error => console.error('Error deleting branch:', error));
        },
        deleteUser(userId) {
            fetch(`/users/delete/${userId}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                console.log('User deleted:', data); // Log the deleted user data
                this.fetchUsers(); // Refresh the users list
                this.showEditUserForm = false; // Hide the edit user form
            })
            .catch(error => console.error('Error deleting user:', error));
        }
    },
    mounted() {
        this.fetchUsers();
        this.fetchBranches();
    }
});

-- Create schema
CREATE SCHEMA IF NOT EXISTS vollies;

-- Use the schema
USE vollies;

-- Drop the existing table if it exists
DROP TABLE IF EXISTS users;

-- Create users table
CREATE TABLE users (
  userid INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(45) NOT NULL,
  phone_number VARCHAR(45) NOT NULL,
  email VARCHAR(90) NOT NULL,
  password VARCHAR(90) NOT NULL,
  user_name VARCHAR(90) NOT NULL,
  associated_branch VARCHAR(90) NOT NULL,
  bool_manager BOOLEAN NOT NULL DEFAULT FALSE,
  bool_admin BOOLEAN NOT NULL DEFAULT FALSE,
  KEY idx_user_full_name (full_name)
);

-- Insert data into users table
INSERT INTO users (full_name, phone_number, email, password, user_name, associated_branch, bool_manager, bool_admin)
VALUES
('Josh Brazier', '0424826995', 'joshbrad20@gmail.com', 'Ismell22', 'JoshBrad', 'Main Branch', FALSE, FALSE),
('Jane Doe', '0123456789', 'jane.doe@example.com', 'password123', 'jane_doe', 'Main Branch', FALSE, TRUE);

-- Drop the existing table if it exists
DROP TABLE IF EXISTS branches;

-- Create branches table
CREATE TABLE branches (
  branchid INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(45) NOT NULL,
  location VARCHAR(90) NOT NULL,
  phone_number VARCHAR(45) NOT NULL,
  email VARCHAR(90) NOT NULL,
  KEY idx_location (location)
);

-- Insert data into branches table
INSERT INTO branches (name, location, phone_number, email)
VALUES
('Main Branch', '123 Main St, Springfield', '123-456-7890', 'mainbranch@example.com'),
('North Branch', '456 North St, Springfield', '123-456-7891', 'northbranch@example.com');

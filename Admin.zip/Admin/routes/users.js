const express = require('express');
const router = express.Router();
const mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'localhost',
  database: 'vollies'
});

// Connect to the database
connection.connect(err => {
  if (err) {
    console.error('Error connecting to the database:', err);
    return;
  }
  console.log('Connected to the MySQL database.');
});

router.get('/', function(req, res, next) {
  connection.query('SELECT * FROM users', function(error, results, fields) {
    if (error) throw error;
    res.json(results);
  });
});

router.get('/:userName', function(req, res, next) {
  const userName = req.params.userName;
  connection.query('SELECT * FROM users WHERE user_name = ?', [userName], function(error, results, fields) {
    if (error) throw error;
    if (results.length > 0) {
      res.json(results[0]);
    } else {
      res.status(404).send('User not found');
    }
  });
});

router.put('/:userName', function(req, res, next) {
  const userName = req.params.userName;
  const updatedUser = req.body;
  connection.query('UPDATE users SET ? WHERE user_name = ?', [updatedUser, userName], function(error, results, fields) {
    if (error) throw error;
    res.json({ message: 'User updated successfully' });
  });
});

module.exports = router;

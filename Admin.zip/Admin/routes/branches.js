const express = require('express');
const router = express.Router();
const mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'localhost',
  database: 'vollies'         // Ensure this matches your database name
});

// Connect to the database
connection.connect(err => {
  if (err) {
    console.error('Error connecting to the database:', err);
    return;
  }
  console.log('Connected to the MySQL database.');
});

router.get('/', function(req, res, next) {
  connection.query('SELECT * FROM branches', function(error, results, fields) {
    if (error) throw error;
    res.json(results);
  });
});

router.post('/add', function(req, res, next) {
    var name = req.body.name;
    var location = req.body.location;
    var phoneNumber = req.body.phone_number;
    var email = req.body.email;

    var query = 'INSERT INTO branches (name, location, phone_number, email) VALUES (?, ?, ?, ?)';
    connection.query(query, [name, location, phoneNumber, email], function(error, results, fields) {
      if (error) throw error;
      res.json({ id: results.insertId, name: name, location: location, phone_number: phoneNumber, email: email });
    });
});

router.put('/edit/:id', function(req, res, next) {
    const branchId = req.params.id;
    const { name, location, phone_number, email } = req.body;

    const query = 'UPDATE branches SET name = ?, location = ?, phone_number = ?, email = ? WHERE id = ?';
    connection.query(query, [name, location, phone_number, email, branchId], function(error, results, fields) {
        if (error) throw error;
        res.json({ message: 'Branch updated successfully' });
    });
});


module.exports = router;
